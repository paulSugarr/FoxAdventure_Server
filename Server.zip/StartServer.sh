#!/bin/bash
sleep 5
cd /home/paul
./Server.exe &
